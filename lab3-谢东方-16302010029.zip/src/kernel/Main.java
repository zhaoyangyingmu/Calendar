package kernel;

import javafx.application.Application;

/*
* Start here!
*
* */
public class Main {
    public static void main(String[] args) {
        Application.launch(Display.class,args);
    }
}
